#!/usr/bin/env python3
"""
funnel_calculator.py -- Step C, Task 6 (Estimate company sales potential)

Reads a filled-in scenarios CSV and prints, for each country, a base case and
every alternative scenario side by side, so the sensitivity is visible rather
than buried in one number.

CSV columns required:
    country, scenario, reachable_customers, conversion_rate_pct,
    price_per_user_usd, period_months, notes

  - country: e.g. "Canada"
  - scenario: "base" or a short label for an alternative, e.g. "slow_adoption"
  - reachable_customers: your Year-1 realistically reachable audience for
    that country (an assumption -- state how you got it in `notes`)
  - conversion_rate_pct: % of reachable customers who become paying users
  - price_per_user_usd: price per paying user for the period
  - period_months: the period this estimate covers (e.g. 12)
  - notes: state your assumption and its source/logic. Required -- a number
    with no stated assumption is not usable in your report.

This script does not invent reachable-customer counts, conversion rates, or
prices. Every number in the CSV has to come from you (the founders), stated
as an assumption if it isn't a cited figure -- this script only does the
arithmetic and lays scenarios next to each other.

Usage:
    python3 funnel_calculator.py path/to/scenarios.csv
"""
import csv
import sys
from collections import defaultdict
from pathlib import Path


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 funnel_calculator.py path/to/scenarios.csv")
        sys.exit(1)

    in_path = Path(sys.argv[1])
    if not in_path.exists():
        print(f"File not found: {in_path}")
        sys.exit(1)

    with in_path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    if not rows:
        print("Scenarios file is empty -- nothing to calculate yet.")
        sys.exit(0)

    by_country = defaultdict(list)
    skipped = []

    for row in rows:
        country = (row.get("country") or "").strip()
        scenario = (row.get("scenario") or "").strip()
        if not country or not scenario:
            continue

        try:
            reach = float(row["reachable_customers"])
            conv = float(row["conversion_rate_pct"])
            price = float(row["price_per_user_usd"])
            months = float(row.get("period_months") or 12)
        except (KeyError, ValueError):
            skipped.append(f"{country} / {scenario} (missing or unparseable number)")
            continue

        notes = (row.get("notes") or "").strip()
        if not notes:
            skipped.append(f"{country} / {scenario} (no assumption noted in 'notes' -- fill this in)")

        paying_users = reach * (conv / 100.0)
        revenue = paying_users * price

        by_country[country].append({
            "scenario": scenario,
            "reach": reach,
            "conv": conv,
            "price": price,
            "months": months,
            "paying_users": paying_users,
            "revenue": revenue,
            "notes": notes,
        })

    if skipped:
        print("Skipped or flagged rows:")
        for s in skipped:
            print(" -", s)
        print()

    for country, scenarios in by_country.items():
        print(f"=== {country} ===")
        print(f"{'Scenario':<16}{'Reachable':>12}{'Conv %':>9}{'Price':>10}{'Paying users':>15}{'Revenue':>14}")
        for s in scenarios:
            print(
                f"{s['scenario']:<16}{s['reach']:>12,.0f}{s['conv']:>8.1f}%"
                f"{s['price']:>10,.2f}{s['paying_users']:>15,.0f}{s['revenue']:>14,.0f}"
            )
        base = next((s for s in scenarios if s["scenario"].lower() == "base"), None)
        others = [s for s in scenarios if s is not base]
        if base and others:
            for o in others:
                if base["revenue"]:
                    delta_pct = (o["revenue"] - base["revenue"]) / base["revenue"] * 100
                    print(f"  {o['scenario']} vs base: {delta_pct:+.0f}% revenue")
        print()

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        countries = list(by_country.keys())
        scenario_names = sorted({s["scenario"] for lst in by_country.values() for s in lst})

        fig, ax = plt.subplots(figsize=(max(6, 1.6 * len(countries)), 5))
        width = 0.8 / max(1, len(scenario_names))
        x = range(len(countries))

        for i, sc in enumerate(scenario_names):
            values = []
            for c in countries:
                match = next((s for s in by_country[c] if s["scenario"] == sc), None)
                values.append(match["revenue"] if match else 0)
            positions = [xi + i * width for xi in x]
            ax.bar(positions, values, width=width, label=sc)

        ax.set_xticks([xi + width * (len(scenario_names) - 1) / 2 for xi in x])
        ax.set_xticklabels(countries)
        ax.set_ylabel("Estimated revenue (USD)")
        ax.set_title("Step C -- Sales potential by country and scenario")
        ax.legend()
        plt.tight_layout()

        out_path = in_path.with_name(in_path.stem + "_chart.png")
        fig.savefig(out_path, dpi=150)
        print(f"Chart saved to: {out_path}")
    except ImportError:
        print("(matplotlib not installed -- skipping chart; the tables above are still complete.)")


if __name__ == "__main__":
    main()
