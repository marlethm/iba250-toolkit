# Sales funnel calculator — Step C, Task 6

A small tool so your team's sales-potential math is transparent and easy to check,
instead of a single number with hidden arithmetic.

## Files

- `scenarios-template.csv` — one row per country per scenario. Fill in a `base`
  row and at least one alternative row (e.g. `slow_adoption`, `strong_pr_push`)
  for each of your top-3 countries. The `notes` column is required — a number
  with no stated assumption behind it isn't usable in your report.
- `funnel_calculator.py` — reads the CSV and prints a side-by-side table per
  country (reachable customers, conversion %, price, paying users, revenue),
  the % difference between each alternative and the base case, and saves a
  comparison bar chart. Tested and working; it never invents a number — every
  input has to come from your team.

## Usage

```
python3 funnel_calculator.py scenarios-template.csv
```

## Where this goes in your report

Use the printed table and chart directly in Section 3, Task 6 (Estimate
company sales potential) and reference it again in Section 4 (Country
Screening Model and Results) if it changes your shortlist reasoning.
