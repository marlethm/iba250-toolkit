# Market Intel Skill — starter kit

A ready-to-use starting point for IBA 250 Assignment 1, Step B. This is the
same structure Claude Code would build for you from scratch — starting from
this kit just guarantees the templates and script already work, so your
team's AI tool only has to fill in the venture-specific parts.

## Folder contents

- `SKILL.md` — the governing instructions, with your venture context left as
  bracketed placeholders. Paste the Step B prompt into your AI tool with
  this folder open, and have it fill in the placeholders with your real
  information.
- `templates/evidence-table.csv`, `templates/scorecard.csv` — empty
  templates for a new run.
- `scripts/score_markets.py` — reads a filled-in scorecard and outputs the
  weighted ranking and a bar chart. Tested and working — it only aggregates
  what's in the file; it never invents a score.
- `logs/change_log.md` — one row per monitoring run, logging what changed.
- `logs/founder_decision_log.md` — one row per monitoring run, logging what
  the founders accepted, rejected, or changed, and why. The AI never fills
  this in.
- `runs/` — empty. Each dated run's filled-in evidence table, scorecard, and
  full narrative output goes here.

## No Python required

Step 5 below (`score_markets.py`) is optional — it's a convenience that
double-checks the arithmetic and draws a chart for teams that already have
Python installed. It is not required to complete Step B: the AI tool
already shows the weighted-score calculation directly in its chat response
for every run, and that alone satisfies the "reproduce the market-screening
logic" requirement. If your team doesn't have Python, skip step 5 and keep
the CSV files as your evidence record (Excel or Google Sheets work fine for
viewing them).

## Getting started

1. Unzip this folder into your team's project repository.
2. Fill in the six bracketed fields in the Step B prompt (see the toolkit
   page) with your real venture information, and paste the whole prompt into
   Claude Code (recommended) or your chat-only AI tool, with this folder
   open.
3. Have it fill in `SKILL.md`'s placeholders with your venture context.
4. Do your first real run: fill in `templates/evidence-table.csv` and
   `templates/scorecard.csv` copied to `runs/<date>-...`, using real data
   from the permitted sources. On this first run, also fill in `SKILL.md`'s
   **Locked indicator list** — the specific named indicator you're using for
   each of the 7 criteria (e.g., "GDP, current US$, World Bank," not just
   "population"). Every later run must reuse those exact same indicators, so
   getting this right on run 1 matters — see `SKILL.md` for why.
5. *(Optional, only if you have Python installed)* run
   `python3 scripts/score_markets.py runs/<date>-scorecard.csv` to get the
   ranked table and chart. If `python3` isn't recognized on your computer,
   skip this step entirely — nothing later in the workflow depends on it.
6. Update `logs/change_log.md`, and have the founders (not the AI) fill in
   `logs/founder_decision_log.md`.
7. Repeat on at least 5 different days before Assignment 1 is due.

See PitchBridge AI's example run under "Worked Example" on the toolkit page
to see what a completed run looks like.
