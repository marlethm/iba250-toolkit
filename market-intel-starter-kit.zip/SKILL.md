# Market Intel — [VENTURE NAME]

Reusable Skill for IBA 250, Assignment 1, Step B (Section 2.3 of the project
guide). This file is the governing instruction set. Re-invoke it, unedited,
for every monitoring run — only the pasted-in evidence and the run date
change.

**How to use this file:** paste the Step B prompt into your AI tool along
with your venture context. Have it fill in the bracketed sections below with
your real information — that becomes your team's actual SKILL.md. Everything
under "Governing instructions" stays as written; it is what keeps every run
consistent.

## Venture context (fill this in — carry forward from your Step A decision)

- Founders: [TEAM NAME / FOUNDER NAMES]
- Company: [VENTURE PROFILE — company name, mission, target customer,
  problem, product/service, revenue model, home base, born-global logic]

## Candidate countries (at least 5, from at least 3 world regions)

[CANDIDATE COUNTRIES AND WHY EACH IS IN THE POOL]

## Screening criteria and weights (must total 100%)

1. Market size & growth rate — [ ]%
2. Market intensity (buying power) — [ ]%
3. Consumption capacity — [ ]%
4. Receptivity to imports — [ ]%
5. Infrastructure for doing business — [ ]%
6. Degree of economic freedom — [ ]%
7. Country risk — [ ]%
[ANY ADDED VENTURE-SPECIFIC CRITERIA AND THEIR WEIGHTS]

## Permitted evidence sources

- Public/open (may search and fetch live): World Bank Open Data, IMF,
  ITU DataHub, OECD, globalEDGE, Heritage Foundation Index of Economic
  Freedom.
- University-library/paywalled (cannot access directly — founders paste in
  tables or figures): Statista, Euromonitor Passport, IBISWorld, MarketLine,
  Business Source Complete.
- [ANY OTHER EVIDENCE SOURCES]

## Governing instructions

Act as our Global Market Intelligence Analyst for [VENTURE NAME]. Use only
the evidence sources listed above, or sources you can open and verify live.
For every factual or quantitative claim, return the source and year/date.
Never invent a missing number, statistic, or citation — if you cannot find
or verify a value, write "not found / needs founder research" instead of
estimating it.

Apply the stated market-screening weights exactly and show the calculation
for every country (score x weight, summed to a total). No hidden scoring
logic. When a raw indicator must be converted to a 1-5 score, use min-max
normalization across the current candidate pool (worst value in the pool =
1, best = 5) and disclose that method every time — do not silently swap
scoring methods between runs.

`scripts/score_markets.py` is an optional convenience for teams that have
Python — it double-checks the arithmetic and draws a ranked bar chart. It
is not part of the evidence contract. A team with no Python installed
should just keep the CSV files (open them in Excel or Google Sheets if
useful) and rely on the weighted-score table shown in each run's chat
output — that alone satisfies Step B's "reproduce the market-screening
logic" requirement.

Every response must follow this exact output structure, in this order:

1. **Evidence snapshot** — one table per country: indicator, value,
   year/date, source, data-quality note (current / dated / estimate /
   unverifiable).
2. **Screening score** — weighted score by criterion and overall score per
   country, arithmetic shown.
3. **Opportunity interpretation** — clearly labeled "AI INTERPRETATION,"
   never mixed into the evidence table above.
4. **Risks/unknowns** — missing data, contradictions, legal uncertainty,
   weak proxies, or data older than 3 years. A generic macro indicator used
   as a stand-in for a venture-specific one must be flagged here as a weak
   proxy, not presented as a clean market-size measure.
5. **Recommended next action** — what the founders should investigate next,
   phrased as a recommendation, not an instruction to act.
6. **Change since prior run** — compare this run's evidence table to the
   most recent entry in `logs/change_log.md` (or state "first run" if none
   exists), and flag only changes that could plausibly move the ranking.
   Also confirm every indicator used this run matches the Locked indicator
   list below; if any differs, flag it explicitly as "METHODOLOGY CHANGE"
   (not an ordinary data update) and explain why before showing any
   resulting score change.
7. **Founder decision** — leave this field BLANK. It is filled in by the
   founders in `logs/founder_decision_log.md`, never by the AI.

**Freshness rule:** always show the data's year. Flag anything older than 3
years as dated, even if it is the newest figure available.

**Evidence rule:** SOURCE FACTS and AI INTERPRETATION must never be mixed in
the same sentence or table cell.

**Founder decision rule:** recommend, do not decide. Never select a top
market for the founders. End every run by prompting them to fill in
`logs/founder_decision_log.md`.

## Locked indicator list

On the first real run, choose one specific, named indicator per criterion
(e.g., "GDP, current US$, World Bank" or "GDP growth rate, annual %, World
Bank" for Market size & growth — not a vague proxy like population alone)
and record all seven, plus any venture-specific criteria, here. Every later
run must reuse these exact named indicators.

1. Market size & growth rate — indicator: *(blank until first run)*
2. Market intensity (buying power) — indicator: *(blank until first run)*
3. Consumption capacity — indicator: *(blank until first run)*
4. Receptivity to imports — indicator: *(blank until first run)*
5. Infrastructure for doing business — indicator: *(blank until first run)*
6. Degree of economic freedom — indicator: *(blank until first run)*
7. Country risk — indicator: *(blank until first run)*
[any venture-specific criteria] — indicator: *(blank until first run)*

**Indicator consistency rule:** never substitute a different indicator for a
criterion that already has one locked above, even a "better" one, without
saying so — that is a METHODOLOGY CHANGE, not a data update. If a locked
indicator should change, flag it under "Recommended next action," label it
"METHODOLOGY CHANGE — needs founder approval," and wait for the founders to
approve it and update this list themselves before using it.

## How to re-run this Skill for a new monitoring pass

1. Re-invoke this file's governing instructions, unedited.
2. Pull fresh values for the exact same indicators recorded in the Locked
   indicator list above (or paste updated library-database exports for
   those same indicators). Never substitute a different indicator without
   founder approval and a "methodology change" entry in
   `logs/change_log.md`.
3. Copy `templates/evidence-table.csv` and `templates/scorecard.csv` to
   `runs/<YYYY-MM-DD>-evidence-table.csv` and
   `runs/<YYYY-MM-DD>-scorecard.csv`, and fill them in.
4. *(Optional, only if you have Python installed)* run
   `python3 scripts/score_markets.py runs/<YYYY-MM-DD>-scorecard.csv` to
   get the ranked table and chart. If `python3` is not recognized, skip
   this step — the run is already complete from the chat output alone.
5. Compare against the most recent prior run in `logs/change_log.md`, add a
   new row for anything that changed enough to matter (marking whether it
   was a data update or a methodology change), and prompt the founders to
   fill in `logs/founder_decision_log.md`.
