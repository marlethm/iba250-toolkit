# Change Log — [VENTURE NAME] Market Intel

One row per monitoring run. Add a row every time you re-invoke the Skill,
even if nothing changed enough to move the ranking — say so explicitly.

Mark "Change type" as **data update** (same locked indicator, new value) or
**methodology change** (a different indicator was used for a criterion —
this requires founder approval per SKILL.md and means this run's ranking is
not directly comparable to prior runs).

| Run date | Indicator / country changed | Old value | New value | Change type (data update / methodology change) | Affects ranking (yes/no/unclear) | Founder note |
|---|---|---|---|---|---|---|
| | | | | | | |
