# Market Intel Skill — starter kit

A ready-to-use starting point for IBA 250 Assignment 1, Step B. This is the
same structure Claude Code would build for you from scratch — starting from
this kit just guarantees the templates and script already work, so your
team's AI tool only has to fill in the venture-specific parts.

## Folder contents

- `SKILL.md` — the governing instructions, with your venture context left as
  bracketed placeholders. Paste the Step B prompt into your AI tool with
  this folder open, and have it fill in the placeholders with your real
  information.
- `templates/evidence-table.csv`, `templates/scorecard.csv` — empty
  templates for a new run.
- `scripts/score_markets.py` — reads a filled-in scorecard and outputs the
  weighted ranking and a bar chart. Tested and working — it only aggregates
  what's in the file; it never invents a score.
- `logs/change_log.md` — one row per monitoring run, logging what changed.
- `logs/founder_decision_log.md` — one row per monitoring run, logging what
  the founders accepted, rejected, or changed, and why. The AI never fills
  this in.
- `runs/` — empty. Each dated run's filled-in evidence table, scorecard, and
  full narrative output goes here.

## Getting started

1. Unzip this folder into your team's project repository.
2. Fill in the six bracketed fields in the Step B prompt (see the toolkit
   page) with your real venture information, and paste the whole prompt into
   Claude Code (recommended) or your chat-only AI tool, with this folder
   open.
3. Have it fill in `SKILL.md`'s placeholders with your venture context.
4. Do your first real run: fill in `templates/evidence-table.csv` and
   `templates/scorecard.csv` copied to `runs/<date>-...`, using real data
   from the permitted sources.
5. Run `python3 scripts/score_markets.py runs/<date>-scorecard.csv` to get
   the ranked table and chart.
6. Update `logs/change_log.md`, and have the founders (not the AI) fill in
   `logs/founder_decision_log.md`.
7. Repeat on at least 5 different days before Assignment 1 is due.

See PitchBridge AI's example run under "Worked Example" on the toolkit page
to see what a completed run looks like.
