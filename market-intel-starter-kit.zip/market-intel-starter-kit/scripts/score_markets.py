#!/usr/bin/env python3
"""
score_markets.py — PitchBridge AI Market Intel Skill

Reads a filled-in scorecard CSV (columns: country, criterion, weight,
raw_score_1to5, weighted_score, evidence_reference) and prints a ranked
weighted-total table, then saves a ranked bar chart as a PNG next to the
input file.

This script never invents or estimates a score. If a country/criterion
cell is blank, it is skipped and flagged in the printed summary rather
than treated as zero.

Usage:
    python3 score_markets.py path/to/scorecard.csv
"""
import csv
import sys
from collections import defaultdict
from pathlib import Path


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 score_markets.py path/to/scorecard.csv")
        sys.exit(1)

    in_path = Path(sys.argv[1])
    if not in_path.exists():
        print(f"File not found: {in_path}")
        sys.exit(1)

    totals = defaultdict(float)
    weight_sum = defaultdict(float)
    missing = []

    with in_path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    if not rows:
        print("Scorecard is empty — nothing to score yet.")
        sys.exit(0)

    for row in rows:
        country = row.get("country", "").strip()
        criterion = row.get("criterion", "").strip()
        weight_raw = row.get("weight", "").strip()
        weighted_raw = row.get("weighted_score", "").strip()
        raw_score = row.get("raw_score_1to5", "").strip()

        if not country or not criterion:
            continue

        if not weighted_raw or not raw_score:
            missing.append(f"{country} / {criterion}")
            continue

        try:
            weighted = float(weighted_raw.rstrip("%"))
            weight = float(weight_raw.rstrip("%")) / 100 if weight_raw.rstrip("%").replace(".", "", 1).isdigit() else None
        except ValueError:
            missing.append(f"{country} / {criterion} (could not parse number)")
            continue

        totals[country] += weighted
        if weight is not None:
            weight_sum[country] += weight

    if missing:
        print("Skipped (missing/unparseable — not counted as zero):")
        for m in missing:
            print(f"  - {m}")
        print()

    ranked = sorted(totals.items(), key=lambda kv: kv[1], reverse=True)

    print("Weighted total score by country (higher = stronger fit):")
    print(f"{'Rank':<5}{'Country':<15}{'Weighted total':<16}{'Weight coverage'}")
    for i, (country, total) in enumerate(ranked, start=1):
        coverage = f"{weight_sum[country]*100:.0f}%" if weight_sum[country] else "n/a"
        print(f"{i:<5}{country:<15}{total:<16.2f}{coverage}")

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        countries = [c for c, _ in ranked]
        values = [v for _, v in ranked]

        plt.figure(figsize=(8, 5))
        plt.barh(countries[::-1], values[::-1], color="#2E5266")
        plt.xlabel("Weighted total score (1-5 scale)")
        plt.title("PitchBridge AI — Country Screening: Weighted Totals")
        plt.tight_layout()

        out_path = in_path.with_name(in_path.stem + "_chart.png")
        plt.savefig(out_path, dpi=150)
        print(f"\nChart saved to: {out_path}")
    except ImportError:
        print("\n(matplotlib not installed — skipping chart; the table above is still complete.)")


if __name__ == "__main__":
    main()
