# Founder Decision Log — [VENTURE NAME] Market Intel

One row per monitoring run. The AI recommends; only the founders decide.
Fill in the second and third columns yourselves — never let the AI fill
these in for you.

| Run date | AI recommendation | Founder decision (accepted/rejected/modified) | Reason |
|---|---|---|---|
| | | | |
