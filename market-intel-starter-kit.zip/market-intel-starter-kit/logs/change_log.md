# Change Log — [VENTURE NAME] Market Intel

One row per monitoring run. Add a row every time you re-invoke the Skill,
even if nothing changed enough to move the ranking — say so explicitly.

| Run date | Indicator / country changed | Old value | New value | Affects ranking (yes/no/unclear) | Founder note |
|---|---|---|---|---|---|
| | | | | | |
