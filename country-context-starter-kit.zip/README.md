# Country Context starter kit

A ready-to-use set of templates for Assignment 2, Steps E and F. These are
the same tables Step E and Step F's prompts ask your AI tool to fill in —
having blank, correctly-columned CSVs on hand means you can drop the AI's
output straight into a spreadsheet instead of retyping a table by hand.

## Folder contents

- `templates/ple-indicators-template.csv` — the required ten-row political/
  legal/economic table from Step E. One row per dimension, per country — copy
  the ten rows again for each additional country.
- `templates/figures-data-template.csv` — long-format data for the two
  required graphs per country plus the one cross-country comparison figure
  from Step E. Feed this to `scripts/plot_country_figures.py` (optional) or
  chart it yourself in Excel/Google Sheets.
- `templates/cultural-comparison-template.csv` — the required 11-dimension
  comparative cultural attributes table from Step F. Fill in one copy per
  selected country.
- `templates/business-environment-synthesis-template.csv` — the Business
  Environment Synthesis / PESTLE-style rating table from Step E.
- `scripts/plot_country_figures.py` — OPTIONAL, only useful if you have
  Python installed. Reads `figures-data-template.csv` and saves one PNG per
  figure into `figures/`: a trend line chart for any country with 2+ years of
  data on one indicator, and a comparison bar chart for any figure covering
  2+ countries. It only charts what's in the file — it never invents or
  estimates a number.
- `figures/` — empty. Chart images land here if you use the script.

## No Python required

Step E and Step F are complete without ever running the script. If you don't
have Python installed, open the CSV files in Excel or Google Sheets, fill
them in with your AI tool's output, and build the same charts there —
Insert → Chart on the filled-in `figures-data-template.csv` does the same job
as the script.

## Getting started

1. Unzip this folder into your team's project repository, next to your Step
   B/C files.
2. Run the Step E prompt (see the toolkit page) and paste its Task 1-2 output
   into `ple-indicators-template.csv` and `figures-data-template.csv` — one
   block of ten rows per country for the first file, one row per
   (figure, country, year) for the second.
3. *(Optional, only if you have Python installed)* run
   `python3 scripts/plot_country_figures.py templates/figures-data-template.csv`
   to generate the required figures as PNGs in `figures/`. If `python3` isn't
   recognized on your computer, skip this step and chart the data yourself.
4. Run the Step F prompt and paste its Task 2 output into
   `cultural-comparison-template.csv` — one copy of the 11 rows per selected
   country.
5. Insert the filled-in tables and generated figures directly into Section 4
   (Political, Legal, and Economic Environment) and Section 5 (Cultural
   Environment) of your report.

See the Stage 2 worked example on the toolkit page (PitchBridge AI selects
Brazil and Indonesia) to see what completed tables and figures look like.
