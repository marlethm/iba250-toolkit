#!/usr/bin/env python3
"""
Plot the required Step E figures (two trend figures per country, plus one
cross-country comparison figure) from a single long-format CSV.

This script is OPTIONAL. It only aggregates and charts numbers you've already
put in the CSV — it never invents or estimates a value. If you don't have
Python installed, open the CSV in Excel or Google Sheets and build the same
charts by hand; nothing else in Step E depends on this script.

Usage:
    python3 scripts/plot_country_figures.py templates/figures-data-template.csv

Input CSV columns (see templates/figures-data-template.csv):
    figure_label, country, indicator, year, value, source

- A (figure_label, country) pair with 2+ distinct years becomes a per-country
  trend line chart.
- A figure_label used across 2+ countries for the SAME year becomes a
  cross-country comparison bar chart.
Output: one PNG per figure, saved into figures/, named after figure_label.
"""
import sys
import csv
import os
from collections import defaultdict

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
except ImportError:
    print("matplotlib is not installed. Run: pip install matplotlib --break-system-packages")
    sys.exit(1)


def load_rows(path):
    rows = []
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        required = {"figure_label", "country", "indicator", "year", "value", "source"}
        missing = required - set(reader.fieldnames or [])
        if missing:
            print(f"CSV is missing required columns: {sorted(missing)}")
            sys.exit(1)
        for r in reader:
            if not r["value"].strip():
                continue  # skip blank template rows
            try:
                r["year"] = int(float(r["year"]))
                r["value"] = float(r["value"])
            except ValueError:
                print(f"Skipping row with non-numeric year/value: {r}")
                continue
            rows.append(r)
    return rows


def main():
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(1)
    csv_path = sys.argv[1]
    out_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(csv_path))), "figures")
    os.makedirs(out_dir, exist_ok=True)

    rows = load_rows(csv_path)
    if not rows:
        print("No filled-in rows found — nothing to plot yet.")
        sys.exit(0)

    by_figure = defaultdict(list)
    for r in rows:
        by_figure[r["figure_label"]].append(r)

    made = []
    for label, group in by_figure.items():
        countries = sorted(set(r["country"] for r in group))
        years = sorted(set(r["year"] for r in group))

        if len(countries) == 1 and len(years) >= 2:
            # Per-country trend chart
            country = countries[0]
            series = sorted(group, key=lambda r: r["year"])
            fig, ax = plt.subplots(figsize=(6, 4))
            ax.plot([r["year"] for r in series], [r["value"] for r in series], marker="o")
            ax.set_title(f"{label} — {country}")
            ax.set_xlabel("Year")
            ax.set_ylabel(series[0]["indicator"])
            sources = sorted(set(r["source"] for r in series))
            fig.text(0.01, 0.01, "Source: " + "; ".join(sources), fontsize=7, va="bottom")
            fig.tight_layout(rect=(0, 0.05, 1, 1))
            out_path = os.path.join(out_dir, f"{label.replace(' ', '_')}.png")
            fig.savefig(out_path, dpi=150)
            plt.close(fig)
            made.append(out_path)

        elif len(countries) >= 2:
            # Cross-country comparison bar chart — use the latest year per country
            latest = {}
            for r in group:
                c = r["country"]
                if c not in latest or r["year"] > latest[c]["year"]:
                    latest[c] = r
            countries_sorted = sorted(latest.keys())
            values = [latest[c]["value"] for c in countries_sorted]
            fig, ax = plt.subplots(figsize=(6, 4))
            ax.bar(countries_sorted, values)
            ax.set_title(label)
            ax.set_ylabel(group[0]["indicator"])
            sources = sorted(set(r["source"] for r in group))
            fig.text(0.01, 0.01, "Source: " + "; ".join(sources), fontsize=7, va="bottom")
            fig.tight_layout(rect=(0, 0.05, 1, 1))
            out_path = os.path.join(out_dir, f"{label.replace(' ', '_')}.png")
            fig.savefig(out_path, dpi=150)
            plt.close(fig)
            made.append(out_path)

        else:
            print(f"Skipping '{label}': needs either 2+ years for one country, "
                  f"or 2+ countries, to make a chart.")

    if made:
        print(f"Saved {len(made)} figure(s) to {out_dir}/:")
        for p in made:
            print(f"  {p}")
    else:
        print("No figures could be made from the data given — check that each "
              "figure_label has either multiple years (trend) or multiple "
              "countries (comparison).")


if __name__ == "__main__":
    main()
